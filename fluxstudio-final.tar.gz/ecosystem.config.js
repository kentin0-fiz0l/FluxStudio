module.exports = {
  apps: [{
    name: 'fluxstudio',
    script: './server.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/fluxstudio-error.log',
    out_file: '/var/log/fluxstudio-out.log',
    log_file: '/var/log/fluxstudio.log'
  }]
};
