import{j as o,am as r}from"./vendor-89gWM14e.js";import"./vendor-socket-BwhHcMHJ.js";function e(){return o.jsx(r,{to:"/team",replace:!0})}export{e as Team};
