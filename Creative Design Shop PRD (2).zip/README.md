
  # Creative Design Shop PRD

  This is a code bundle for Creative Design Shop PRD. The original project is available at https://www.figma.com/design/69F4TKV901IEd3CQbpY5zy/Creative-Design-Shop-PRD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  